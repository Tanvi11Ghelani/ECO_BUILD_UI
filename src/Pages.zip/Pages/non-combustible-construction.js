import React from 'react';
import image1 from '../images/Icons/below-the-construction-slope.svg';
import image2 from '../images/Icons/flammable-construction.svg';
import image3 from '../images/Icons/Non-combustible-construction.svg';
import image4 from '../images/Icons/firewall.svg';
import image5 from '../images/Icons/form-unit-profiles.svg';
import image6 from '../images/Icons/BIM-library.svg';
import image7 from '../images/Icons/early-design-criteria.svg';
import image8 from '../images/Icons/early-design-criteria-1.svg';
import image9 from '../images/Icons/pdf-gray.svg';
import image10 from '../images/Icons/Download.svg';
import image11 from '../images/Icons/dwg.svg';
import { Link } from 'react-router-dom';
import { useTranslation } from "react-i18next";

const NonCombustibleConstruction = () => {
    const { t } = useTranslation();
    return (
        <div>
            <div className="container">
             <div className="breadcrumb-band">
             <div className="text-band">
                 <span>{t('non_combustible_construction')}</span>
                 <h2>{t('building_homes_also_for_the_generations_to_come')}</h2>
             </div>
         </div>
         </div>
            <section>
      <div className="container">
        <div className="row g-4">

          <div className="col-md-3">
            <div className="card icon-top-primary-card h-245">
              <Link to="/belowtheconstructionslope" className="icon-card top-icon-band blue cus-p-16">
                <div className="icon-band">
                  <img src={image1} alt={t('below_the_construction_slope')} />
                </div>
              </Link>
              <div className="text-band">
                <h4>{t('below_the_construction_slope')}</h4>
              </div>
            </div>
          </div>

          <div className="col-md-3">
            <div className="card icon-top-primary-card h-245">
              <Link to="/flamableconstruction" className="icon-card top-icon-band yellow cus-p-16">
                <div className="icon-band">
                  <img src={image2} alt={t('flammable_construction')} />
                </div>
              </Link>
              <div className="text-band">
                <h4>{t('flammable_construction')}</h4>
              </div>
            </div>
          </div>

          <div className="col-md-3">
            <div className="card icon-top-primary-card h-245">
              <Link to="/noncombstibleconstruction" className="icon-card top-icon-band gray cus-p-16">
                <div className="icon-band">
                  <img src={image3} alt={t('non_combustible_construction')} />
                </div>
              </Link>
              <div className="text-band">
                <h4>{t('non_combustible_construction')}</h4>
              </div>
            </div>
          </div>

          <div className="col-md-3">
            <div className="card icon-top-primary-card h-245">
              <Link to="/firewall" className="icon-card top-icon-band red cus-p-16">
                <div className="icon-band">
                  <img src={image4} alt={t('firewall')} />
                </div>
              </Link>
              <div className="text-band">
                <h4>{t('firewall')}</h4>
              </div>
            </div>
          </div>

          <div className="col-md-3">
            <div className="card icon-top-primary-card h-245">
              <Link to="/formunitprofile" className="icon-card top-icon-band green cus-p-16">
                <div className="icon-band">
                  <img src={image5} alt={t('form_unit_profiles')} />
                </div>
              </Link>
              <div className="text-band">
                <h4>{t('form_unit_profiles')}</h4>
              </div>
            </div>
          </div>

          <div className="col-md-3">
            <div className="card icon-top-primary-card h-245">
              <Link to="/bimlibrary" className="icon-card top-icon-band orange cus-p-16">
                <div className="icon-band">
                  <img src={image6} alt={t('bim_library')} />
                </div>
              </Link>
              <div className="text-band">
                <h4>{t('bim_library')}</h4>
              </div>
            </div>
          </div>

          <div className="col-md-3">
            <div className="card icon-top-primary-card h-245">
              <Link to="/earlydesigncriteria" className="icon-card top-icon-band purple cus-p-16">
                <div className="icon-band">
                  <img src={image7} alt={t('early_design_criteria')} />
                </div>
              </Link>
              <div className="text-band">
                <h4>{t('early_design_criteria')}</h4>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
            <section className="pt-0">
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-md-12">
                            <div className="layer_content p-0">
                                <h3 className="text-primary mb-3">{t('non_combustible_construction')}</h3>
                                <p className="dark-font-600 mt-2 mb-2">{t('use_this_section_to_learn_more_and_see_examples_of_how_to_use_nudura_icfs_for_non_combustible_building_applications_a_key_advantage_of_using_icfs_is_faster_installation_times_which_you_can_achieve_when_the_floor_to_ceiling_height_stays_the_same_on_each_in_a_multi_storey_building')}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section className="pt-0">
               <div className="container">
                   <div className="search-penal bg-penal">
                           <div className="left-penal">
                               <div className="form-group w-30">
                                   <label htmlFor="inputEmail4" className="form-label">{t('file_name')}</label>
                                   <input type="email" className="form-control" id="inputEmail4" placeholder={t('search_here')} />
                               </div>
                               <div className="form-group w-40">
                                   <label htmlFor="inputEmail4" className="form-label">{t('thickness')}</label>
                                   <input type="email" className="form-control" id="inputEmail4" placeholder={t('search_here')} />
                               </div>
                               <div className="form-group w-30 border-none">
                                   <label htmlFor="inputEmail4" className="form-label">{t('description')}</label>
                                   <input type="email" className="form-control" id="inputEmail4" placeholder={t('search_here')} />
                               </div>
                           </div>
                           <div className="right-penal">
                               <a href="#" className="btn-primary">{t('search')}<i className="fa-solid fa-magnifying-glass"></i></a>
                               <a href="#" className="btn-primary white-border-btn">{t('search_advanced')}</a>
                           </div>

                   </div>
               </div>
            </section>
            <section className="pt-0">
                <div className="container">
                    <ul className="nav nav-pills tabs-action-band round-tab mb-5 w-100" id="pills-tab" role="tablist">
                    <li className="nav-item" role="presentation">
                        <button className="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">{t('slab_on_grade')}</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">{t('grade_at_floor')}</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">{t('intermediate_floor')}</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link border-none" id="pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#pills-disabled" type="button" role="tab" aria-controls="pills-disabled" aria-selected="false">{t('roof_connections')}</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link border-none" id="pills-doors-tab" data-bs-toggle="pill" data-bs-target="#pills-doors" type="button" role="tab" aria-controls="pills-doors" aria-selected="false">{t('doors')}</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link border-non w-fill" id="pills-intermediate-tab" data-bs-toggle="pill" data-bs-target="#pills-intermediate" type="button" role="tab" aria-controls="pills-intermediate" aria-selected="false">{t('demising_wall_intermediate_floor_connections')}</button>
                    </li>
                    <li className="nav-item" role="presentation">
                        <button className="nav-link border-none" id="pills-window-tab" data-bs-toggle="pill" data-bs-target="#pills-window" type="button" role="tab" aria-controls="pills-window" aria-selected="false">{t('windows')}</button>
                    </li>
                    </ul>
                </div>
                <div className="container">
                <div className="tab-content" id="pills-tabContent">
                    
                    <div className="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
                        
                        <section className="white-bg pt-0">
                            <div className="titile-band">
                                <h3 className="text-primary text-center">{t('slab_on_grade')}</h3>
                            </div>
                            <table className="dltrc" style={{background:"none"}}>
                                <tbody>
                                    <tr className="dlheader">
                                    <td className="dlheader">{t('description')}</td>
                                    <td className="dlheader">{t('core_thickness')}</td>
                                    <td className="dlheader">{t('cladding_type')}</td>
                                    <td className="dlheader">{t('insulation')}</td>
                                    <td className="dlheader">{t('file_name')}</td>
                                    <td className="dlheader">{t('explanation_page')}</td>
                                    <td className="dlheader">{t('files')}</td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                                                            <li><a href="#" className="red-link">
                                                                                                    <div className="icon-band"><img src={image9} />
                                                                                                    </div>{t('pdf')}<img src={image10}
                                                                                                        className="download-icon" />
                                                                                                </a></li>
                                                                                            <li><a href="#" className="blue-link">
                                                                                                    <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                                </a></li>
                                                                                        </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                                                            <li><a href="#" className="red-link">
                                                                                                    <div className="icon-band"><img src={image9} />
                                                                                                    </div>{t('pdf')}<img src={image10}
                                                                                                        className="download-icon" />
                                                                                                </a></li>
                                                                                            <li><a href="#" className="blue-link">
                                                                                                    <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                                </a></li>
                                                                                        </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                                                           <li><a href="#" className="red-link">
                                                                                                   <div className="icon-band"><img src={image9} />
                                                                                                   </div>{t('pdf')}<img src={image10}
                                                                                                       className="download-icon" />
                                                                                               </a></li>
                                                                                           <li><a href="#" className="blue-link">
                                                                                                   <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                               </a></li>
                                                                                       </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                                                           <li><a href="#" className="red-link">
                                                                                                   <div className="icon-band"><img src={image9} />
                                                                                                   </div>{t('pdf')}<img src={image10}
                                                                                                       className="download-icon" />
                                                                                               </a></li>
                                                                                           <li><a href="#" className="blue-link">
                                                                                                   <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                               </a></li>
                                                                                       </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                                                            <li><a href="#" className="red-link">
                                                                                                    <div className="icon-band"><img src={image9} />
                                                                                                    </div>{t('pdf')}<img src={image10}
                                                                                                        className="download-icon" />
                                                                                                </a></li>
                                                                                            <li><a href="#" className="blue-link">
                                                                                                    <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                                </a></li>
                                                                                        </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                                                            <li><a href="#" className="red-link">
                                                                                                    <div className="icon-band"><img src={image9} />
                                                                                                    </div>{t('pdf')}<img src={image10}
                                                                                                        className="download-icon" />
                                                                                                </a></li>
                                                                                            <li><a href="#" className="blue-link">
                                                                                                    <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                                </a></li>
                                                                                        </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                        </section>
                    </div>
                    
                    <div className="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
                       
                        <section className="white-bg pt-0">
                            <table className="dltrc" style={{background:"none"}}>
                                <tbody>
                                    <tr className="dlheader">
                                    <td className="dlheader">{t('description')}</td>
                                    <td className="dlheader">{t('core_thickness')}</td>
                                    <td className="dlheader">{t('cladding_type')}</td>
                                    <td className="dlheader">{t('insulation')}</td>
                                    <td className="dlheader">{t('file_name')}</td>
                                    <td className="dlheader">{t('explanation_page')}</td>
                                    <td className="dlheader">{t('files')}</td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                                                           <li><a href="#" className="red-link">
                                                                                                   <div className="icon-band"><img src={image9} />
                                                                                                   </div>{t('pdf')}<img src={image10}
                                                                                                       className="download-icon" />
                                                                                               </a></li>
                                                                                           <li><a href="#" className="blue-link">
                                                                                                   <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                               </a></li>
                                                                                       </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                                                            <li><a href="#" className="red-link">
                                                                                                    <div className="icon-band"><img src={image9} />
                                                                                                    </div>{t('pdf')}<img src={image10}
                                                                                                        className="download-icon" />
                                                                                                </a></li>
                                                                                            <li><a href="#" className="blue-link">
                                                                                                    <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                                </a></li>
                                                                                        </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                        </section>
                    </div>
                    
                    <div className="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">
                        
                        <section className="white-bg pt-0">
                            <table className="dltrc" style={{background:"none"}}>
                                <tbody>
                                    <tr className="dlheader">
                                    <td className="dlheader">{t('description')}</td>
                                    <td className="dlheader">{t('core_thickness')}</td>
                                    <td className="dlheader">{t('cladding_type')}</td>
                                    <td className="dlheader">{t('insulation')}</td>
                                    <td className="dlheader">{t('file_name')}</td>
                                    <td className="dlheader">{t('explanation_page')}</td>
                                    <td className="dlheader">{t('files')}</td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                                                           <li><a href="#" className="red-link">
                                                                                                   <div className="icon-band"><img src={image9} />
                                                                                                   </div>{t('pdf')}<img src={image10}
                                                                                                       className="download-icon" />
                                                                                               </a></li>
                                                                                           <li><a href="#" className="blue-link">
                                                                                                   <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                               </a></li>
                                                                                       </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                                                            <li><a href="#" className="red-link">
                                                                                                    <div className="icon-band"><img src={image9} />
                                                                                                    </div>{t('pdf')}<img src={image10}
                                                                                                        className="download-icon" />
                                                                                                </a></li>
                                                                                            <li><a href="#" className="blue-link">
                                                                                                    <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                                </a></li>
                                                                                        </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                                                            <li><a href="#" className="red-link">
                                                                                                    <div className="icon-band"><img src={image9} />
                                                                                                    </div>{t('pdf')}<img src={image10}
                                                                                                        className="download-icon" />
                                                                                                </a></li>
                                                                                            <li><a href="#" className="blue-link">
                                                                                                    <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                                </a></li>
                                                                                        </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                       <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                          <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                        </section>
                    </div>
                    
                    <div className="tab-pane fade" id="pills-disabled" role="tabpanel" aria-labelledby="pills-disabled-tab" tabindex="0">
                        
                        <section className="white-bg pt-0">
                            <table className="dltrc" style={{background:"none"}}>
                                <tbody>
                                    <tr className="dlheader">
                                    <td className="dlheader">{t('description')}</td>
                                    <td className="dlheader">{t('core_thickness')}</td>
                                    <td className="dlheader">{t('cladding_type')}</td>
                                    <td className="dlheader">{t('insulation')}</td>
                                    <td className="dlheader">{t('file_name')}</td>
                                    <td className="dlheader">{t('explanation_page')}</td>
                                    <td className="dlheader">{t('files')}</td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                                                           <li><a href="#" className="red-link">
                                                                                                   <div className="icon-band"><img src={image9} />
                                                                                                   </div>{t('pdf')}<img src={image10}
                                                                                                       className="download-icon" />
                                                                                               </a></li>
                                                                                           <li><a href="#" className="blue-link">
                                                                                                   <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                               </a></li>
                                                                                       </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                                                            <li><a href="#" className="red-link">
                                                                                                    <div className="icon-band"><img src={image9} />
                                                                                                    </div>{t('pdf')}<img src={image10}
                                                                                                        className="download-icon" />
                                                                                                </a></li>
                                                                                            <li><a href="#" className="blue-link">
                                                                                                    <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                                </a></li>
                                                                                        </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                                                            <li><a href="#" className="red-link">
                                                                                                    <div className="icon-band"><img src={image9} />
                                                                                                    </div>{t('pdf')}<img src={image10}
                                                                                                        className="download-icon" />
                                                                                                </a></li>
                                                                                            <li><a href="#" className="blue-link">
                                                                                                    <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                                </a></li>
                                                                                        </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                        <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                          <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                        </section>
                    </div>
                    
                    <div className="tab-pane fade" id="pills-doors" role="tabpanel" aria-labelledby="pills-doors-tab" tabindex="0">
                        
                        <section className="white-bg pt-0">
                            <table className="dltrc" style={{background:"none"}}>
                                <tbody>
                                    <tr className="dlheader">
                                    <td className="dlheader">{t('description')}</td>
                                    <td className="dlheader">{t('core_thickness')}</td>
                                    <td className="dlheader">{t('cladding_type')}</td>
                                    <td className="dlheader">{t('insulation')}</td>
                                    <td className="dlheader">{t('file_name')}</td>
                                    <td className="dlheader">{t('explanation_page')}</td>
                                    <td className="dlheader">{t('files')}</td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                                                            <li><a href="#" className="red-link">
                                                                                                    <div className="icon-band"><img src={image9} />
                                                                                                    </div>{t('pdf')}<img src={image10}
                                                                                                        className="download-icon" />
                                                                                                </a></li>
                                                                                            <li><a href="#" className="blue-link">
                                                                                                    <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                                </a></li>
                                                                                        </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                                                            <li><a href="#" className="red-link">
                                                                                                    <div className="icon-band"><img src={image9} />
                                                                                                    </div>{t('pdf')}<img src={image10}
                                                                                                        className="download-icon" />
                                                                                                </a></li>
                                                                                            <li><a href="#" className="blue-link">
                                                                                                    <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                                </a></li>
                                                                                        </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                                                           <li><a href="#" className="red-link">
                                                                                                   <div className="icon-band"><img src={image9} />
                                                                                                   </div>{t('pdf')}<img src={image10}
                                                                                                       className="download-icon" />
                                                                                               </a></li>
                                                                                           <li><a href="#" className="blue-link">
                                                                                                   <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                               </a></li>
                                                                                       </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                                                            <li><a href="#" className="red-link">
                                                                                                    <div className="icon-band"><img src={image9} />
                                                                                                    </div>{t('pdf')}<img src={image10}
                                                                                                        className="download-icon" />
                                                                                                </a></li>
                                                                                            <li><a href="#" className="blue-link">
                                                                                                    <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                                </a></li>
                                                                                        </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                                                           <li><a href="#" className="red-link">
                                                                                                   <div className="icon-band"><img src={image9} />
                                                                                                   </div>{t('pdf')}<img src={image10}
                                                                                                       className="download-icon" />
                                                                                               </a></li>
                                                                                           <li><a href="#" className="blue-link">
                                                                                                   <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                               </a></li>
                                                                                       </ul>
                                        </td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                        </section>
                    </div>
                    
                    <div className="tab-pane fade" id="pills-intermediate" role="tabpanel" aria-labelledby="pills-intermediate-tab" tabindex="0">
                        
                        <section className="white-bg pt-0">
                            <table className="dltrc" style={{background:"none"}}>
                                <tbody>
                                    <tr className="dlheader">
                                    <td className="dlheader">{t('description')}</td>
                                    <td className="dlheader">{t('core_thickness')}</td>
                                    <td className="dlheader">{t('cladding_type')}</td>
                                    <td className="dlheader">{t('insulation')}</td>
                                    <td className="dlheader">{t('file_name')}</td>
                                    <td className="dlheader">{t('explanation_page')}</td>
                                    <td className="dlheader">{t('files')}</td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                                                           <li><a href="#" className="red-link">
                                                                                                   <div className="icon-band"><img src={image9} />
                                                                                                   </div>{t('pdf')}<img src={image10}
                                                                                                       className="download-icon" />
                                                                                               </a></li>
                                                                                           <li><a href="#" className="blue-link">
                                                                                                   <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                               </a></li>
                                                                                       </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                        </section>
                    </div>

                     
                    <div className="tab-pane fade" id="pills-window" role="tabpanel" aria-labelledby="pills-window-tab" tabindex="0">
                        
                        <section className="white-bg pt-0">
                            <table className="dltrc" style={{background:"none"}}>
                                <tbody>
                                    <tr className="dlheader">
                                    <td className="dlheader">{t('description')}</td>
                                    <td className="dlheader">{t('core_thickness')}</td>
                                    <td className="dlheader">{t('cladding_type')}</td>
                                    <td className="dlheader">{t('insulation')}</td>
                                    <td className="dlheader">{t('file_name')}</td>
                                    <td className="dlheader">{t('explanation_page')}</td>
                                    <td className="dlheader">{t('files')}</td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                            <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status">{t('isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                                                           <li><a href="#" className="red-link">
                                                                                                   <div className="icon-band"><img src={image9} />
                                                                                                   </div>{t('pdf')}<img src={image10}
                                                                                                       className="download-icon" />
                                                                                               </a></li>
                                                                                           <li><a href="#" className="blue-link">
                                                                                                   <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                                                               </a></li>
                                                                                       </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                          <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr className="dlinfo">
                                        <td className="dlinfo hover01">{t('insulated_brick_6_152mm')}</td>
                                        <td className="dlinfo hover01">{t('6')}</td>
                                        <td className="dlinfo hover01"><span className="status with-bricks">{t('with_bricks')}</span></td>
                                        <td className="dlinfo hover01"><span className="status not-isolated">{t('not_isolated')}</span></td>
                                        <td className="dlinfo hover01">{t('b6c10')}</td>
                                        <td className="dlinfo hover01"><a href="#" className="explanation-link">{t('explanation_page')}</a></td>
                                        <td className="dlinfo hover01">
                                           <ul className="file-list-inner-td">
                                                    <li><a href="#" className="red-link">
                                                            <div className="icon-band"><img src={image9} />
                                                            </div>{t('pdf')}<img src={image10}
                                                                className="download-icon" />
                                                        </a></li>
                                                    <li><a href="#" className="blue-link">
                                                            <div className="icon-band"><img src={image11} /></div>{t('dwg')}<img src={image10} className="download-icon" />
                                                        </a></li>
                                                </ul>
                                        </td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                        </section>
                    </div>

                </div>
                </div>

               
            </section>
        </div>
    );
}

export default NonCombustibleConstruction;