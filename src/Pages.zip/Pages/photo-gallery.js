// Import images at the top of your component file
import img1 from "../images/gallery/gallery-img-all-01.jpg";
import img2 from "../images/gallery/gallery-img-all-02.jpg";
import img3 from "../images/gallery/gallery-img-all-03.jpg";
import img4 from "../images/gallery/gallery-img-all-04.jpg";
import img5 from "../images/gallery/gallery-img-all-05.jpg";
import img6 from "../images/gallery/gallery-img-all-06.jpg";
import img7 from "../images/gallery/gallery-img-all-07.jpg";
import img8 from "../images/gallery/gallery-img-all-08.jpg";
import img9 from "../images/gallery/gallery-img-all-09.jpg";
import img10 from "../images/gallery/gallery-img-all-10.jpg";
import img11 from "../images/gallery/gallery-img-all-11.jpg";
import img12 from "../images/gallery/gallery-img-all-12.jpg";
import { useState, useRef, useEffect } from "react";
import api from "../HTTP/baseURLMain";
import { useTranslation } from "react-i18next";

const images = [
  img1, img2, img3, img4, img5, img6,
  img7, img8, img9, img10, img11, img12
];

const PhotoGallery = () => {
    const { t } = useTranslation();
    const [galleryItems, setGalleryItems] = useState([]);

    const token = localStorage.getItem("accessToken");
    // Fetch gallery dropdown items
    useEffect(() => {
        const fetchGallery = async () => {
            try {
                // const response = await fetch("https://api.example.com/gallery-menu"); // replace with your API
                // const data = await response.json();
                // setGalleryItems(data); // expecting an array of { title, path }
                api.get("/cms/gallery/", {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }).then((res) => {
                    setGalleryItems(res.data.data.results);
                });

            } catch (error) {
                console.error("Error fetching gallery menu:", error);
            }
        };

        fetchGallery();
    }, []);
    return (
        <div>
            <div className="container">
            <div className="breadcrumb-band">
                <div className="text-band">
                    <span>{t('gallery')}</span>
                    <h2>{t('building_homes_also_for_the_generations_to_come')}</h2>
                </div>
            </div>
        </div>
            <section>
                <div className="container">
                    <ul className="nav nav-pills tabs-action-band" id="pills-tab" role="tablist">
                        <li className="nav-item" role="presentation">
                            <button className="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home"
                                aria-selected="true">{t('show_all')}</button>
                        </li>
                        <li className="nav-item" role="presentation">
                            <button className="nav-link" id="pills-profile-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile"
                                aria-selected="false">{t('gallery_of_completed_projects')}</button>
                        </li>
                        <li className="nav-item" role="presentation">
                            <button className="nav-link" id="pills-contact-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact"
                                aria-selected="false">{t('projects_under_construction')}</button>
                        </li>
                        <li className="nav-item" role="presentation">
                            <button className="nav-link border-none" id="pills-disabled-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-disabled" type="button" role="tab" aria-controls="pills-disabled"
                                aria-selected="false">{t('ecobuild_events')}</button>
                        </li>
                    </ul>
                </div>
                <div className="tab-content" id="pills-tabContent">
                    
                    <div className="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab"
                        tabindex="0">
                        
                        <section>
                            <div className="container">
                                    <div className="row g-4">
                                        {galleryItems
                                            .filter((item) => item.image) // ✅ keep only items with image
                                            .map((item, index) => (
                                                <div className="col-sm-6 col-md-6 col-lg-4 col-xl-3" key={item.id || index}>
                                                    <div className="gallery-img-card">
                                                        <img
                                                            src={item.image}
                                                            alt={item.category?.name || `Gallery ${index + 1}`}
                                                        />
                                                    </div>
                                                </div>
                                            ))}

                                    </div>
                            </div>
                        </section>
                    </div>
                    
                    <div className="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab"
                        tabindex="0">
                        
                        <section>
                            <div className="container">
                                <div className="row g-4">
                                        {images.map((img, index) => (
                                            <div className="col-sm-6 col-md-6 col-lg-4 col-xl-3" key={index}>
                                                <div className="gallery-img-card">
                                                    <img src={img} alt={`Gallery ${index + 1}`} />
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                            </div>
                        </section>
                    </div>
                    
                    <div className="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab"
                        tabindex="0">
                        
                        <section>
                            <div className="container">
                                <div className="row g-4">
                                        {images.map((img, index) => (
                                            <div className="col-sm-6 col-md-6 col-lg-4 col-xl-3" key={index}>
                                                <div className="gallery-img-card">
                                                    <img src={img} alt={`Gallery ${index + 1}`} />
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                            </div>
                        </section>
                    </div>
                    
                    <div className="tab-pane fade" id="pills-disabled" role="tabpanel" aria-labelledby="pills-disabled-tab"
                        tabindex="0">
                        
                        <section>
                            <div className="container">
                                <div className="row g-4">
                                        {images.map((img, index) => (
                                            <div className="col-sm-6 col-md-6 col-lg-4 col-xl-3" key={index}>
                                                <div className="gallery-img-card">
                                                    <img src={img} alt={`Gallery ${index + 1}`} />
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                            </div>
                        </section>
                    </div>
                </div>


            </section>
        </div>
    );
}
export default PhotoGallery;