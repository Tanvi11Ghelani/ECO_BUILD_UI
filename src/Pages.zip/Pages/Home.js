import React from 'react';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import './slider.css';
import product1 from '../images/prod-1.png';
import product2 from '../images/prod-2.png';
import product3 from '../images/prod-3.png';
import product4 from '../images/prod-4.png';
import product5 from '../images/prod-5.png';
import product6 from '../images/prod-6.png';
import b1 from '../images/eota-brand_logo.png';
import b2 from '../images/Icon3.png';
import b3 from '../images/Icon4.png';
import b4 from '../images/Icon5.png';
import b5 from '../images/Icon6.png';
import img from '../images/Img2.png';
import img2 from '../images/Img3.png';
import { hide } from '@popperjs/core';
import { useTranslation } from "react-i18next";


const Home = () => {
    const { t } = useTranslation();
  const settings = {
    dots: true,          // show navigation dots
    infinite: true,      // infinite loop
    speed: 500,          // transition speed
    slidesToShow: 4,     // how many items visible
    slidesToScroll: 1,   // how many items move on scroll
    autoplay: true,      // auto play
    autoplaySpeed: 1000, // speed for autoplay
    centerMode:false
  };
  return (
      <div style={{overflow: "hidden !important"}}>
          <section className="hero-band">
              <div className="container">
                  <div className="row">
                      <div className="hero-text-band">
                          <span className="sub-head">{t('nudura_insulated_concrete_forms_and_panels')}</span>
                          <h1 className="main-head">{t('nudura_israel')}<br />{t('advanced_ecological_building_systems')}</h1>

                          <div className="btn-group">
                              <a href="#" className="btn-primary">{t('subscribe_renew_here')}<ion-icon
                                      name="arrow-forward"></ion-icon></a>
                              <a href="#" className="btn-secondary border-line-btn">{t('icf_method')}</a>
                          </div>
                      </div>
                      <div className="search-penal">
                          <div className="left-penal">
                              <div className="form-group w-30">
                                  <label htmlFor="inputState" className="form-label">{t('product_type')}</label>
                                  <select id="inputState" className="form-select">
                                      <option defaultValue>{t('all_products')}</option>
                                      <option>{t('')}</option>
                                  </select>
                              </div>
                              <div className="form-group w-30">
                                  <label htmlFor="inputEmail4" className="form-label">{t('sizes')}</label>
                                  <input type="email" className="form-control" id="inputEmail4" placeholder={t('sizes')} />
                              </div>
                              <div className="form-group w-40 border-none">
                                  <label htmlFor="inputEmail4" className="form-label">{t('keyword')}</label>
                                  <input type="email" className="form-control" id="inputEmail4" placeholder={t('search_keyword')} />
                              </div>
                          </div>
                          <div className="right-penal">
                              <a href="#" className="btn-primary">{t('search')}<i className="fa-solid fa-magnifying-glass"></i></a>
                          </div>

                      </div>
                  </div>
              </div>
          </section>
          <section className="white-bg">
              <div className="container">
                  <div className="titile-band">
                      <span>{t('featured_products')}</span>
                      <h3>{t('recommended_for_you')}</h3>
                  </div>
                  <div className="row g-4">
                      <div className="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                          <div className="card gradient-card">
                              <div className="img-band w-100">
                                  <img src={product1} />
                              </div>
                              <div className="text-band p-3">
                                  <h5>{t('the_nudura_icf_series')}</h5>
                                  <ul>
                                      <li><span>{t('type')}</span>{t('4_way_flip')}</li>
                                      <li><span>{t('size')}</span>{t('4_way_flip')}</li>
                                      <li><span>{t('shape')}</span>{t('all_shapes')}</li>
                                  </ul>
                                  <div className="review-band">
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-regular fa-star"></i></span>
                                      <p>{t('45_reviews')}</p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div className="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                          <div className="card gradient-card">
                              <div className="img-band w-100 bg-white">
                                  <img src={product2} />
                              </div>
                              <div className="text-band p-3">
                                  <h5>{t('casa_lomas_de_machal_machas')}</h5>
                                  <ul>
                                      <li><span>{t('type')}</span>{t('4_way_flip')}</li>
                                      <li><span>{t('size')}</span>{t('4_way_flip')}</li>
                                      <li><span>{t('shape')}</span>{t('all_shapes')}</li>
                                  </ul>
                                  <div className="review-band">
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-regular fa-star"></i></span>
                                      <p>{t('45_reviews')}</p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div className="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                          <div className="card gradient-card">
                              <div className="img-band w-100">
                                  <img src={product3} />
                              </div>
                              <div className="text-band p-3">
                                  <h5>{t('casa_lomas_de_machal_machas')}</h5>
                                  <ul>
                                      <li><span>{t('type')}</span>{t('4_way_flip')}</li>
                                      <li><span>{t('size')}</span>{t('4_way_flip')}</li>
                                      <li><span>{t('shape')}</span>{t('all_shapes')}</li>
                                  </ul>
                                  <div className="review-band">
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-regular fa-star"></i></span>
                                      <p>{t('45_reviews')}</p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div className="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                          <div className="card gradient-card">
                              <div className="img-band w-100">
                                  <img src={product4} />
                              </div>
                              <div className="text-band p-3">
                                  <h5>{t('casa_lomas_de_machal_machas')}</h5>
                                  <ul>
                                      <li><span>{t('type')}</span>{t('4_way_flip')}</li>
                                      <li><span>{t('size')}</span>{t('4_way_flip')}</li>
                                      <li><span>{t('shape')}</span>{t('all_shapes')}</li>
                                  </ul>
                                  <div className="review-band">
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-regular fa-star"></i></span>
                                      <p>{t('45_reviews')}</p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div className="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                          <div className="card gradient-card">
                              <div className="img-band w-100">
                                  <img src={product5} />
                              </div>
                              <div className="text-band p-3">
                                  <h5>{t('casa_lomas_de_machal_machas')}</h5>
                                  <ul>
                                      <li><span>{t('type')}</span>{t('4_way_flip')}</li>
                                      <li><span>{t('size')}</span>{t('4_way_flip')}</li>
                                      <li><span>{t('shape')}</span>{t('all_shapes')}</li>
                                  </ul>
                                  <div className="review-band">
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-regular fa-star"></i></span>
                                      <p>{t('45_reviews')}</p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div className="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                          <div className="card gradient-card">
                              <div className="img-band w-100">
                                  <img src={product6} />
                              </div>
                              <div className="text-band p-3">
                                  <h5>{t('casa_lomas_de_machal_machas')}</h5>
                                  <ul>
                                      <li><span>{t('type')}</span>{t('4_way_flip')}</li>
                                      <li><span>{t('size')}</span>{t('4_way_flip')}</li>
                                      <li><span>{t('shape')}</span>{t('all_shapes')}</li>
                                  </ul>
                                  <div className="review-band">
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-solid fa-star"></i></span>
                                      <span><i className="fa-regular fa-star"></i></span>
                                      <p>{t('45_reviews')}</p>
                                  </div>
                              </div>
                          </div>
                      </div>

                      <div className="action-band d-flex align-item-center justify-content-center">
                          <a href="#" className="btn-primary icon-btn">{t('view_all_products')}<i
                                  className="fa-solid fa-arrow-right"></i></a>
                      </div>

                  </div>
              </div>
          </section>
          <section className="white-bg pt-0">
              <div className="container">
                  <div className="card gredient-card bg-primary-gradient">
                      <div className="text-band text-left">
                          <h5>{t('why_nudura')}</h5>
                          <h6 className="text-white">{t('choosing_nudura_integrated_building_technology_products_for_your_next_design_project_is_undoubtedly_the_smart_and_right_choice_for_today_s_complex_design_challenges')}<br /><br />{t('the_eps_formwork_system_for_casting_nodora_s_unique_concrete_walls_which_significantly_differentiates_them_from_other_concrete_formwork_products_or_traditional_construction_methods_available_on_the_market_today_for_a_smart_economical_and_greenest_construction_method')}<br /><br />

                          </h6>
                          <p>{t('on_the_other_hand_nodora_leads_the_way_and_sets_new_standards_showing_planners_engineers_and_contractors_a_smart_fast_efficient_and_advanced_approach_to_both_planning_solutions_and_the_construction_of_residential_and_commercial_buildings')}<br /><br />{t('nudura_s_award_winning_energy_efficient_technology_means_a_more_efficient_green_building_approach_that_outperforms_all_known_construction_methods_especially_in_the_construction_of_conventional_building_envelope_walls')}</p>
                      </div>
                  </div>
              </div>
          </section>
          <section className="white-bg pt-0">
              <div className="container-fuild">
                  <div className="titile-band">
                      <h3>{t('standard_certification')}</h3>
                  </div>
                  <div className="slider-band">
                        <Slider {...settings}>
                          <div className="item pl-2">
                              <div className="border-card">
                                  <div className="img-band">
                                      <img src={b1} />
                                  </div>
                                  <div className="text-band">
                                      <h3>{t('european_organisation_for_technical_assessment')}</h3>
                                      <p>{t('the_european_organisation_for_technical_assessment_eota_is_a_europe_wide_association_of_technical_assessment_bodies_for_construction_products_established_under_the_construction_products_regulation_cpr')}</p>
                                  </div>
                                  <div className="action-band mt-3 d-flex align-item-center justify-content-center">
                                      <a href="#" className="btn-primary icon-btn border-btn-primary">{t('learn_more')}<i
                                              className="fa-solid fa-arrow-right"></i></a>
                                  </div>
                              </div>
                          </div>
                          <div className="item pl-2">
                              <div className="border-card">
                                  <div className="img-band">
                                      <img src={b2} />
                                  </div>
                                  <div className="text-band">
                                      <h3>{t('es_icc_evaluation_service')}</h3>
                                      <p>{t('icc_es_is_a_certification_body_a_subsidiary_of_the_international_code_council_icc_that_provides_technical_evaluations_and_product_certifications_for_code_compliance')}</p>
                                  </div>
                                  <div className="action-band mt-3 d-flex align-item-center justify-content-center">
                                      <a href="#" className="btn-primary icon-btn border-btn-primary">{t('learn_more')}<i
                                              className="fa-solid fa-arrow-right"></i></a>
                                  </div>
                              </div>
                          </div>
                          <div className="item pl-2">
                              <div className="border-card">
                                  <div className="img-band">
                                      <img src={b3} />
                                  </div>
                                  <div className="text-band">
                                      <h3>{t('iso_9001_2015')}</h3>
                                      <p>{t('the_gii_is_proud_to_update_its_quality_management_system_to_iso_9001_2015_and_provide_consistent_top_quality_geophysical_services_to_it_s_clients')}</p>
                                  </div>
                                  <div className="action-band mt-3 d-flex align-item-center justify-content-center">
                                      <a href="#" className="btn-primary icon-btn border-btn-primary">{t('learn_more')}<i
                                              className="fa-solid fa-arrow-right"></i></a>
                                  </div>
                              </div>
                          </div>
                          <div className="item pl-2">
                              <div className="border-card">
                                  <div className="img-band">
                                      <img src={b4} />
                                  </div>
                                  <div className="text-band">
                                      <h3>{t('uk_green_building_council')}</h3>
                                      <p>{t('green_buildings_are_therefore_characterised_by_a_high_quality_ecological_design_and_superior_resource_efficiency_in_the_areas_of_energy_water_and_materials_damaging_effects_on_health_and_the_environment_are_reduced_to_a_minimum')}</p>
                                  </div>
                                  <div className="action-band mt-3 d-flex align-item-center justify-content-center">
                                      <a href="#" className="btn-primary icon-btn border-btn-primary">{t('learn_more')}<i
                                              className="fa-solid fa-arrow-right"></i></a>
                                  </div>
                              </div>
                          </div>
                          <div className="item pl-2">
                              <div className="border-card">
                                  <div className="img-band">
                                      <img src={b5} />
                                  </div>
                                  <div className="text-band">
                                      <h3>{t('council_of_icf_industries')}</h3>
                                      <p>{t('the_insulating_concrete_forms_manufacturers_association_icfma_is_the_north_american_non_profit_trade_association_for_the_insulated_concrete_form_industry_and_was_founded_in_2014_by_a_dedicated_group_of_manufacturers_with_the_interest_of_improving_the_quality_and_acceptance_of_insulated_concrete_form_construction')}</p>
                                  </div>
                                  <div className="action-band mt-3 d-flex align-item-center justify-content-center">
                                      <a href="#" className="btn-primary icon-btn border-btn-primary">{t('learn_more')}<i
                                              className="fa-solid fa-arrow-right"></i></a>
                                  </div>
                              </div>
                          </div>
                          </Slider>
                      </div>
              </div>
          </section>
          <section className="light-bg pt-0 pb-0">
              <div className="container-fuild">
                  <div className="row g-0">
                      <div className="col-12 col-md-12 col-lg-6 col-xl-6">
                          <div className="layer_image">
                              <img src="Images/benifit-banner.jpg" />
                          </div>

                      </div>
                      <div className="col-12 col-md-12 col-lg-6 col-xl-6">
                          <div className="layer_content">
                              <span className="sub-head-small text-blue">{t('your_benifit')}</span>
                              <h3>{t('why_choose_ecobuild_system_ltd')}</h3>
                              <p>{t('embarked_on_a_global_search_visiting_8_countries_and_reviewing_11_advanced_building_systems_after_extensive_consultation_with_architects_contractors_and_engineers_we_found_one_solution_that_stood_out_nudura_icf_examining_eleven_different_construction_methods_in_depth')}</p>

                              <ul className="icon-card-white">
                                  <li>
                                      <div className="icon-band">
                                          <img src="Images/Icons/Proven-Expertise.svg" />
                                      </div>
                                      <div className="text-band">
                                          <h4>{t('proven_expertise')}</h4>
                                          <p>{t('our_seasoned_team_excels_in_icf_products_with_years_of_successful_market_navigation_offering_informed_decisions_and_optimal_results')}</p>
                                      </div>
                                  </li>
                                  <li>
                                      <div className="icon-band">
                                          <img src="Images/Icons/Customized-Solutions.svg" />
                                      </div>
                                      <div className="text-band">
                                          <h4>{t('customized_solutions')}</h4>
                                          <p>{t('we_pride_ourselves_on_crafting_personalised_strategies_to_match_your_unique_goals_ensuring_a_seamless_latest_constructions_journey')}</p>
                                      </div>
                                  </li>
                                  <li>
                                      <div className="icon-band">
                                          <img src="Images/Icons/Transparent-Partnerships.svg" />
                                      </div>
                                      <div className="text-band">
                                          <h4>{t('transparent_partnerships')}</h4>
                                          <p>{t('transparency_is_key_in_our_client_relationships_we_prioritize_clear_communication_and_ethical_practices_fostering_trust_and_reliability_throughout')}</p>
                                      </div>
                                  </li>
                              </ul>
                          </div>

                      </div>
                  </div>

              </div>
          </section>
          <section className="light-bg testimonials-section">
              <div className="container-fuild">

                  <div className="titile-band">
                      <span className="sub-head-small text-blue">{t('our_testimonials')}</span>
                      <h3>{t('what_do_the_customers_write_about_us')}</h3>
                      <p>{t('we_don_t_just_build_buildings_we_research_and_develop_new_products_every_day_to_improve_and_advance_the_construction_industry_in_israel')}</p>
                  </div>

                  <div className="slider-band">
                      {/* <div className="owl-carousel testimonials-slider owl-theme"> */}
                      <Slider {...settings}>
                          <div className="item">
                              <div className="card">
                                  <div className="icon-band">
                                      <img src="Images/Icons/msg-mark.svg" />
                                  </div>
                                  <div className="text-band p-0">
                                      <p>{t('my_experience_with_property_management_services_has_exceeded_expectations_they_efficiently_manage_properties_with_a_professional_and_attentive_approach_in_every_situation_i_feel_reassured_that_any_issue_will_be_resolved_promptly_and_effectively')}</p>
                                      <div className="profile-card">
                                          <div className="profile-img">
                                              <img src="Images/profile-01.jpg" />
                                          </div>
                                          <div className="profile-text">
                                              <h6>{t('courtney_henry')}</h6>
                                              <span>{t('ceo_themesflat')}</span>
                                              <div className="review-band">
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>

                          <div className="item">
                              <div className="card">
                                  <div className="icon-band">
                                      <img src="Images/Icons/msg-mark.svg" />
                                  </div>
                                  <div className="text-band p-0">
                                      <p>{t('my_experience_with_property_management_services_has_exceeded_expectations_they_efficiently_manage_properties_with_a_professional_and_attentive_approach_in_every_situation_i_feel_reassured_that_any_issue_will_be_resolved_promptly_and_effectively')}</p>
                                      <div className="profile-card">
                                          <div className="profile-img">
                                              <img src="Images/profile-01.jpg" />
                                          </div>
                                          <div className="profile-text">
                                              <h6>{t('courtney_henry')}</h6>
                                              <span>{t('ceo_themesflat')}</span>
                                              <div className="review-band">
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>

                          <div className="item">
                              <div className="card">
                                  <div className="icon-band">
                                      <img src="Images/Icons/msg-mark.svg" />
                                  </div>
                                  <div className="text-band p-0">
                                      <p>{t('my_experience_with_property_management_services_has_exceeded_expectations_they_efficiently_manage_properties_with_a_professional_and_attentive_approach_in_every_situation_i_feel_reassured_that_any_issue_will_be_resolved_promptly_and_effectively')}</p>
                                      <div className="profile-card">
                                          <div className="profile-img">
                                              <img src="Images/profile-01.jpg" />
                                          </div>
                                          <div className="profile-text">
                                              <h6>{t('courtney_henry')}</h6>
                                              <span>{t('ceo_themesflat')}</span>
                                              <div className="review-band">
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>

                          <div className="item">
                              <div className="card">
                                  <div className="icon-band">
                                      <img src="Images/Icons/msg-mark.svg" />
                                  </div>
                                  <div className="text-band p-0">
                                      <p>{t('my_experience_with_property_management_services_has_exceeded_expectations_they_efficiently_manage_properties_with_a_professional_and_attentive_approach_in_every_situation_i_feel_reassured_that_any_issue_will_be_resolved_promptly_and_effectively')}</p>
                                      <div className="profile-card">
                                          <div className="profile-img">
                                              <img src="Images/profile-01.jpg" />
                                          </div>
                                          <div className="profile-text">
                                              <h6>{t('courtney_henry')}</h6>
                                              <span>{t('ceo_themesflat')}</span>
                                              <div className="review-band">
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>

                          <div className="item">
                              <div className="card">
                                  <div className="icon-band">
                                      <img src="Images/Icons/msg-mark.svg" />
                                  </div>
                                  <div className="text-band p-0">
                                      <p>{t('my_experience_with_property_management_services_has_exceeded_expectations_they_efficiently_manage_properties_with_a_professional_and_attentive_approach_in_every_situation_i_feel_reassured_that_any_issue_will_be_resolved_promptly_and_effectively')}</p>
                                      <div className="profile-card">
                                          <div className="profile-img">
                                              <img src="Images/profile-01.jpg" />
                                          </div>
                                          <div className="profile-text">
                                              <h6>{t('courtney_henry')}</h6>
                                              <span>{t('ceo_themesflat')}</span>
                                              <div className="review-band">
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>

                          <div className="item">
                              <div className="card">
                                  <div className="icon-band">
                                      <img src="Images/Icons/msg-mark.svg" />
                                  </div>
                                  <div className="text-band p-0">
                                      <p>{t('my_experience_with_property_management_services_has_exceeded_expectations_they_efficiently_manage_properties_with_a_professional_and_attentive_approach_in_every_situation_i_feel_reassured_that_any_issue_will_be_resolved_promptly_and_effectively')}</p>
                                      <div className="profile-card">
                                          <div className="profile-img">
                                              <img src="Images/profile-01.jpg" />
                                          </div>
                                          <div className="profile-text">
                                              <h6>{t('courtney_henry')}</h6>
                                              <span>{t('ceo_themesflat')}</span>
                                              <div className="review-band">
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>

                          <div className="item">
                              <div className="card">
                                  <div className="icon-band">
                                      <img src="Images/Icons/msg-mark.svg" />
                                  </div>
                                  <div className="text-band p-0">
                                      <p>{t('my_experience_with_property_management_services_has_exceeded_expectations_they_efficiently_manage_properties_with_a_professional_and_attentive_approach_in_every_situation_i_feel_reassured_that_any_issue_will_be_resolved_promptly_and_effectively')}</p>
                                      <div className="profile-card">
                                          <div className="profile-img">
                                              <img src="Images/profile-01.jpg" />
                                          </div>
                                          <div className="profile-text">
                                              <h6>{t('courtney_henry')}</h6>
                                              <span>{t('ceo_themesflat')}</span>
                                              <div className="review-band">
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                                  <span><i className="fa-solid fa-star"></i></span>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>
                        </Slider>

                      {/* </div> */}
                  </div>



              </div>
          </section>
          <section className="white-bg">
              <div className="container-fuild">
                  <div className="titile-band">
                      <h3>{t('trusted_by_over_150_major_companies')}</h3>
                  </div>
                  <div className="brand-card-band">
                      <ul>
                          <li><a href="#" target="_blank"> <img src="Images/brand-logo/brand-01.png" /> </a></li>
                          <li><a href="#" target="_blank"> <img src="Images/brand-logo/brand-02.png" /> </a></li>
                          <li><a href="#" target="_blank"> <img src="Images/brand-logo/brand-03.png" /> </a></li>
                          <li><a href="#" target="_blank"> <img src="Images/brand-logo/brand-04.png" /> </a></li>
                          <li><a href="#" target="_blank"> <img src="Images/brand-logo/brand-05.png" /> </a></li>
                          <li><a href="#" target="_blank"> <img src="Images/brand-logo/brand-06.png" /> </a></li>
                      </ul>
                  </div>
              </div>
          </section>
          <section className="light-bg blog-section">
              <div className="container">
                  <div className="titile-band">
                      <span className="sub-head-small text-blue">{t('latest_new')}</span>
                      <h3>{t('green_building_information')}</h3>
                  </div>
                  <div className="row g-4">
                      <div className="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                          <div className="card">
                              <div className="img-band">
                                  <img src="Images/blog-01.jpg" />
                                  <div className="blog-date">
                                      <p>{t('may_31_2025')}</p>
                                  </div>
                              </div>
                              <div className="text-band">
                                  <h4>{t('what_is_green_building')}</h4>
                                  <p>{t('for_many_anything_that_is_considered_green_is_considered_environmentally_friendly_and_meets_the_need_to_prevent_as_many_harmful_effects_on_the_planet_as_possible_while_providing_an_ecological_and_considerate_solution_for_people_who_want_a_home_at_a_reasonable_price_and_without_harming_the_environment')}</p>
                                  <a href="#">{t('read_more')}</a>
                              </div>
                          </div>
                      </div>
                      <div className="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                          <div className="card">
                              <div className="img-band">
                                  <img src={img} />
                                  <div className="blog-date">
                                      <p>{t('may_31_2025')}</p>
                                  </div>
                              </div>
                              <div className="text-band">
                                  <h4>{t('the_benefits_of_green_building_using_the_nudura_method')}</h4>
                                    <p>{t('one_of_the_unique_methods_of_green_construction_is_the_nudura_method_a_canadian_method_with_modular_and_insulated_construction_forms_in_which_the_concrete_is_poured_but_without_sacrificing_the_excellent')}</p>
                                  <a href="#">{t('read_more')}</a>
                              </div>
                          </div>
                      </div>
                      <div className="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                          <div className="card">
                              <div className="img-band">
                                  <img src={img2} />
                                  <div className="blog-date">
                                      <p>{t('may_31_2025')}</p>
                                  </div>
                              </div>
                              <div className="text-band">
                                  <h4>{t('design_libraries_made_from_ecological_materials')}</h4>
                                  <p>{t('the_icf_method_has_many_advantages_one_of_the_main_advantages_is_a_significant_saving_in_construction_installation_times_which_makes_any_project_extremely_fast_the_technology_allows_for_stable')}</p>
                                  <a href="#">{t('read_more')}</a>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </section>
      </div>
  );
};

export default Home;