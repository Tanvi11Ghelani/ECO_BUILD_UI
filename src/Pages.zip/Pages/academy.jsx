import thumb from '../images/thumnail.jpg';
import book from '../images/Icons/book.svg';
import finance from '../images/Icons/finance-mode-rounded.svg';
import clock from '../images/Icons/clock-light.svg';
import docwrite from '../images/Icons/doc-write.svg';
import { useTranslation } from "react-i18next";

const Academy = () => {
    const { t } = useTranslation();

    return (
        <div>
            <div className="container">
                <div className="breadcrumb-band">
                    <div className="text-band">
                        <span>{t("academy.breadcrumb.title")}</span>
                        <h2>{t("academy.breadcrumb.subtitle")}</h2>
                    </div>
                </div>
            </div>
            <section>
                <div className="container">
                    <div className="titile-band text-left">
                        <h3 className="text-primary text-left">{t("academy.sectionTitle")}</h3>
                    </div>

                    <div className="row g-4">

                        <div className="col-md-6">
                            <div className="icon-card m-height-128 pyx-15-25">
                                <div className="icon-band bg-icon">
                                    <img src={book} />
                                </div>
                                <div className="text-band">
                                    <h5 className="mb-0 text-white">
                                        {t("academy.cards.instructionBook")}
                                    </h5>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-6">
                            <div className="icon-card m-height-128 pyx-15-25">
                                <div className="icon-band bg-icon">
                                    <img src={finance} />
                                </div>
                                <div className="text-band">
                                    <h5 className="mb-0 text-white">
                                        {t("academy.cards.courseCost")}
                                    </h5>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-6">
                            <div className="icon-card m-height-128 pyx-15-25">
                                <div className="icon-band bg-icon">
                                    <img src={clock} />
                                </div>
                                <div className="text-band">
                                    <h5 className="mb-0 text-white">
                                        {t("academy.cards.courseHours")}
                                    </h5>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-6">
                            <div className="icon-card m-height-128 pyx-15-25">
                                <div className="icon-band bg-icon">
                                    <img src={docwrite} />
                                </div>
                                <div className="text-band">
                                    <h5 className="mb-0 text-white">
                                        {t("academy.cards.registration")}
                                    </h5>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div className="info-msg-band mt-4">
                        <h4>{t("academy.important.title")}</h4>
                        <p className="bold-bg">
                            {t("academy.important.text")}
                        </p>
                    </div>
                </div>
            </section>
            <section className="pt-0">
                <div className="container">
                    <div className="titile-band">
                        <h3>{t("academy.videos.title")}</h3>
                    </div>

                    <div className="row g-4">

                        {[...Array(9)].map((_, i) => (
                            <div className="col-md-4" key={i}>
                                <button className="video-btn" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                    <div className="video-card">
                                        <div className="thumnail-img">
                                            <img src={thumb} />
                                            <a className="play-btn"><i className="fa-solid fa-play"></i></a>
                                        </div>
                                        <div className="text-band">
                                            <h5 className="mb-0 text-white">
                                                {t("academy.videos.videoTitle")}
                                            </h5>
                                        </div>
                                    </div>
                                </button>
                            </div>
                        ))}

                    </div>

                    <div className="pagination-band">
                        <nav aria-label={t('')}>
                            <ul className="pagination">
                                <li className="page-item">
                                    <span className="page-link"><i className="fa-solid fa-angle-left"></i></span>
                                </li>
                                <li className="page-item"><a className="page-link" href="#">1</a></li>
                                <li className="page-item active">
                                    <span className="page-link">
                                        2
                                        <span className="sr-only">{t('current')}</span>
                                    </span>
                                </li>
                                <li className="page-item"><a className="page-link" href="#">3</a></li>
                                <li className="page-item">
                                    <a className="page-link" href="#"><i className="fa-solid fa-chevron-right"></i></a>
                                </li>
                            </ul>
                        </nav>
                    </div>

                </div>
            </section>
            <div className="modal fade video-model-band" id="exampleModal" tabIndex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">

                        <div className="modal-body">
                            <iframe width="560" height="315" id="cartoonVideo"
                                src="https://www.youtube.com/embed/_bOJ974vi7w?si=aGmjy6vWYv4XZYSb?"
                                autitle="YouTube video player" frameBorder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                referrerPolicy="strict-origin-when-cross-origin" allowFullScreen></iframe>
                        </div>

                        <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label={t('close')}></button>

                    </div>
                </div>
            </div>
        </div>
    );
};

export default Academy;
