import { useState, useEffect } from "react";
import api from "../HTTP/baseURLMain";
import { useTranslation } from "react-i18next";

const VideoGalery = () => {
  const { t } = useTranslation();
  const [galleryItems, setGalleryItems] = useState([]);
  const [selectedVideo, setSelectedVideo] = useState(null); // ✅ track clicked video
  const token = localStorage.getItem("accessToken");

  useEffect(() => {
    const fetchGallery = async () => {
      try {
        api
          .get("/cms/gallery/", {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          })
          .then((res) => {
            setGalleryItems(res.data.data.results);
          });
      } catch (error) {
        console.error("Error fetching gallery menu:", error);
      }
    };

    fetchGallery();
  }, [token]);

  return (
    <div>
      <div className="container">
        <div className="breadcrumb-band">
          <div className="text-band">
            <span>{t('video_gallery')}</span>
            <h2>{t('building_homes_also_for_the_generations_to_come')}</h2>
          </div>
        </div>
      </div>
      <section>
        <div className="container">
          <div className="row g-4">
            {galleryItems
              .filter((item) => item.video) // ✅ only videos
              .map((item, index) => (
                <div
                  className="col-sm-6 col-md-6 col-lg-4 col-xl-4"
                  key={item.id || index}
                >
                  <button
                    className="video-btn"
                    type="button"
                    data-bs-toggle="modal"
                    data-bs-target="#exampleModal"
                    onClick={() => setSelectedVideo(item.video)} // ✅ set clicked video
                  >
                    <div className="video-card">
                      <div className="thumnail-img">
                        {/* show thumbnail (first frame of video) */}
                        <video className="w-100" preload="metadata" muted>
                          <source src={item.video + "#t=0.5"} type="video/mp4" />
                        </video>
                        <a className="play-btn">
                          <i className="fa-solid fa-play"></i>
                        </a>
                      </div>
                      <div className="text-band">
                        <h5 className="mb-0 text-white">
                          {index + 1}. {item.category?.name || "Untitled Video"}
                        </h5>
                      </div>
                    </div>
                  </button>
                </div>
              ))}
          </div>

          {/* ✅ Bootstrap Modal */}
          <div
            className="modal fade"
            id="exampleModal"
            tabIndex="-1"
            aria-hidden="true"
          >
            <div className="modal-dialog modal-lg modal-dialog-centered">
              <div className="modal-content bg-dark">
                <div className="modal-header">
                  <h5 className="modal-title text-white">{t('video_player')}</h5>
                  <button
                    type="button"
                    className="btn-close btn-close-white"
                    data-bs-dismiss="modal"
                    aria-label={t('close')}
                  ></button>
                </div>
                <div className="modal-body text-center">
                  {selectedVideo ? (
                    <video
                      key={selectedVideo} // reset playback on new video
                      className="w-100"
                      controls
                      autoPlay
                    >
                      <source src={selectedVideo} type="video/mp4" />{t('your_browser_does_not_support_the_video_tag')}</video>
                  ) : (
                    <p className="text-white">{t('no_video_selected')}</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* pagination remains same */}
          <div className="pagination-band">
            <nav aria-label={t('')}>
              <ul className="pagination">
                <li className="page-item">
                  <span className="page-link">
                    <i className="fa-solid fa-angle-left"></i>
                  </span>
                </li>
                <li className="page-item">
                  <a className="page-link" href="#">
                    1
                  </a>
                </li>
                <li className="page-item active">
                  <span className="page-link">
                    2<span className="sr-only">{t('current')}</span>
                  </span>
                </li>
                <li className="page-item">
                  <a className="page-link" href="#">
                    3
                  </a>
                </li>
                <li className="page-item">
                  <a className="page-link" href="#">
                    <i className="fa-solid fa-chevron-right"></i>
                  </a>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </section>
    </div>
  );
};

export default VideoGalery;
