import pdf from "../images/Icons/pdf-gray.svg";
import download from "../images/Icons/Download.svg";
import pdffile from "../images/Icons/pdf-fille.svg";
import { useTranslation } from "react-i18next";


const StandardAndLaboratoryCertification = () => {
  const { t } = useTranslation();
  return (
    <div>
      <div className="container">
        <div className="breadcrumb-band">
          <div className="text-band">
            <span>{t('standard_and_laboratory_certifications')}</span>
            <h2>{t('building_homes_also_for_the_generations_to_come')}</h2>
          </div>
        </div>
      </div>
      <section>
        <div className="container">
          <div className="row align-items-center">
            <div className="col-md-12">
              <div className="layer_content p-0">
                <h3 className="text-primary mb-5">{t('standard_and_laboratory_certifications')}</h3>
                <p className="dark-font-600 mt-3 mb-2">{t('nudura_products_have_been_tested_and_approved_to_ensure_they_meet_western_standards_as_well_as_the_following_european_standards')}</p>
                <h6 className="mb-0 mt-5 mb-4 font-bg-700">{t('explosion_resistance_test_results_report')}</h6>
              </div>
              <h6 className="mb-3 mt-5">{t('file_attachments')}</h6>
              <div className="file-list">
                <div className="file-card">
                  <a
                    href="https://ecobuild.co.il/wp-content/uploads/2021/01/hydrofoam_520_compressed.pdf"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <div className="file-icon-band">
                      <img src={pdffile} alt={t('pdf_icon')} />
                    </div>
                    <div className="file-name-band">
                      <p>{t('fped_report_pdf')}</p>
                      <span className="small-icon">
                        <img src={download} alt={t('download')} />
                      </span>
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* Example iframe fix */}
      <div className="full-video-card mt-5">
        <div className="video-band">
          <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed/iS0Dl92_on4?si=07u7F_BiLBsCYJbQ"
            title={t('youtube_video_player')}
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            referrerPolicy="strict-origin-when-cross-origin"
            allowFullScreen
          ></iframe>
        </div>
      </div>
      {/* Example table fix */}
      <table
        className="dltrc table-left-align"
        style={{ background: "none" }}
      >
        <tbody>
          <tr className="dlheader">
            <td className="dlheader">{t('notes')}</td>
            <td className="dlheader">{t('file')}</td>
          </tr>
          <tr className="dlinfo">
            <td className="dlinfo hover01">{t('nudura_response_to_fire_classification_report_no_ra11_0329_according_to_eu_standard_nf_en_13501_1_english')}</td>
            <td className="dlinfo hover01">
              <ul className="file-list-inner-td justify-content-start">
                <li>
                  <a href="#" className="red-link border-none">
                    <div className="icon-band">
                      <img src={pdf} alt={t('pdf_icon')} />
                    </div>{t('pdf')}<img
                      src={download}
                      alt={t('download')}
                      className="download-icon"
                    />
                  </a>
                </li>
              </ul>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default StandardAndLaboratoryCertification;
