import React, { useState, useRef, useEffect } from "react";
import { OpenAI } from "openai";
import "./chat-window.css";
import { useTranslation } from "react-i18next";

export default function EcoChat({ open, onClose }) {
  const { t } = useTranslation();
  const [chatStarted, setChatStarted] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Hello 👋 Nice to see you here!" },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (open) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, open]);

  if (!open) return null; // 👈 hides the chat when closed

  const client = new OpenAI({
    apiKey:
      "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",
    dangerouslyAllowBrowser: true,
  });

  const handleStart = () => setChatStarted(true);
  const handleMinimize = () => setIsMinimized(!isMinimized);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = { role: "user", content: input };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    try {
      const response = await client.chat.completions.create({
        model: "gpt-4o-mini",
        messages: newMessages,
      });

      const aiMessage = {
        role: "assistant",
        content: response.choices[0].message.content,
      };

      setMessages([...newMessages, aiMessage]);
    } catch (error) {
      console.error("Error:", error);
      setMessages([
        ...newMessages,
        {
          role: "assistant",
          content: "Sorry, I ran into an issue. Please try again.",
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`chat-popup ${isMinimized ? "minimized" : ""}`}>
      <div className="chat-window">
        <div className="chat-header">
          <span>{t('ecobuild_assistant')}</span>
          <div className="chat-header-buttons" style={{ marginBottom:"30px" }}>
            <button
              className="close-btn"
              style={{ color: "black",marginRight:"30px" }}
              onClick={handleMinimize}
            >
              {isMinimized ? "▢" : "—"}
            </button>
            <button className="close-btn" style={{ color: "black" }} onClick={onClose}>
              ✕
            </button>
          </div>
        </div>

        {!isMinimized && (
          <>
            {!chatStarted ? (
              <div className="chat-body">
                <div className="chat-avatar" />
                <p>
                  <strong>{t('hello_nice_to_see_you_here')}</strong>
                </p>
                <p>{t('by_pressing_the_start_chat_button_you_agree_to_have_your_personal_data_processed_as_described_in_our_privacy_policy')}</p>
                <button className="start-btn" onClick={handleStart}>{t('start_chat')}</button>
              </div>
            ) : (
              <>
                <div className="chat-active">
                  {messages.map((msg, i) => (
                    <div
                      key={i}
                      className={`message ${
                        msg.role === "assistant" ? "bot" : "user"
                      }`}
                    >
                      {msg.content}
                    </div>
                  ))}
                  {loading && (
                    <div className="message bot">{t('assistant_is_typing')}</div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                <div className="input-bar">
                  <input
                    type="text"
                    placeholder={t('write_a_message')}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSend()}
                  />
                  <button className="send-btn" onClick={handleSend}>
                    ➤
                  </button>
                </div>
              </>
            )}
            <div className="chat-footer">{t('powered_by')}<strong>{t('ecobuild_system_ltd')}</strong>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
