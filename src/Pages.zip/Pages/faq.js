import { useState, useRef, useEffect } from "react";
import api from "../HTTP/baseURLMain";
import { useTranslation } from "react-i18next";


const FAQ = () => {
    const { t } = useTranslation();
    const [faqs, setFaqs] = useState([]);
    const [loading, setLoading] = useState(true);

    const token = localStorage.getItem("accessToken");
      useEffect(() => {
        const fetchGallery = async () => {
            try {
                api.get("/cms/faq/", {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }).then((res) => {
                    // ✅ Access results array correctly
                    debugger;
                    setFaqs(res.data.data.results || []);
                    setLoading(false);

                });

            } catch (error) {
                console.error("Error fetching gallery menu:", error);
            }
        };

        fetchGallery();
    }, []);

    return (
        <div>
            <div className="container">
            <div className="breadcrumb-band">
                <div className="text-band">
                    <span>{t('frequently_asked_questions')}</span>
                    <h2>{t('building_homes_also_for_the_generations_to_come')}</h2>
                </div>
            </div>
        </div>
            <section>
                <div className="container">
                    <div className="search-penal bg-penal adv-search-peanl">
                        <div className="left-penal">
                            <div className="form-group">
                                <i className="fa-solid fa-magnifying-glass"></i>
                                <input type="text" className="form-control" id="inputEmail4" placeholder={t('search_advanced')} />
                            </div>
                        </div>
                        <div className="right-penal">
                            <a href="#" className="btn-primary">{t('search')}<i className="fa-solid fa-magnifying-glass"></i></a>

                        </div>

                    </div>
                </div>
            </section>
            <section className="pt-0">
              <div className="container">
                <div className="row">
                  <div className="col-md-12">
                    <div className="layer_content p-0">
                      {faqs.length > 0 ? (
                        faqs.map((faq, index) => (
                          <div key={faq.id}>
                            <h6 className="mb-0 mt-3 mb-3 font-bg-700">
                              {index + 1}. {faq.question}
                            </h6>
                            <div className="text-band flex-text-band">
                              <p className="bold-bg">{faq.answer}</p>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p>{t('no_faqs_available')}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </section>
            {/* <section className="pt-0">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12">
                            <div className="layer_content p-0">
                                <h3 className="text-primary">Structural strength and safety</h3>
                                <h6 className="mb-0 mt-3 mb-3 font-bg-700">6. Are NUDURA walls stronger than traditional
                                    construction?</h6>
                                <div className="text-band flex-text-band">
                                    <p className="bold-bg">Yes! NUDURA walls are 6 times stronger than traditional construction
                                        and 2 times stronger than reinforced concrete, thanks to the cast concrete and rigid
                                        structure..</p>
                                </div>

                                <h6 className="mb-0 mt-3 mb-3 font-bg-700">7. Can NUDURA replace MMD?</h6>
                                <div className="text-band flex-text-band">
                                    <p className="bold-bg">Absolutely! Especially with NUDURA Series 1 or a complete structure
                                        made of NUDURA, which is 2 times stronger than a solid core, so the entire house
                                        functions as an improved solid core except for the windows.</p>
                                </div>

                                <h6 className="mb-0 mt-3 mb-3 font-bg-700">8. Are NUDURA walls explosion-proof?</h6>
                                <div className="text-band flex-text-band">
                                    <p className="bold-bg">Yes! NUDURA meets military tests and provides better protection
                                        against blast waves and shrapnel.</p>
                                </div>

                                <h6 className="mb-0 mt-3 mb-3 font-bg-700">9. Can NUDURA be used on military bases?</h6>
                                <div className="text-band flex-text-band">
                                    <p className="bold-bg">Yes! NUDURA is suitable for bunkers, military bases, sensitive
                                        facilities and military warehouses. Thanks to its high durability, the US military
                                        uses this method to build its bases in the US and abroad.</p>
                                </div>

                                <h6 className="mb-0 mt-3 mb-3 font-bg-700">10. Are the walls breakable?</h6>
                                <div className="text-band flex-text-band">
                                    <p className="bold-bg">Not easily. Unlike blocks that can be broken with a hammer, NUDURA
                                        walls are made of solid concrete, making them virtually unbreakable.</p>
                                </div>

                            </div>


                        </div>
                    </div>

                </div>
            </section> */}
        </div>
    );
}

export default FAQ;