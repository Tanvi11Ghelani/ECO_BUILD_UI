// ./Pages/Footer.jsx
import React from 'react';
import { Link } from 'react-router-dom';
import './footer.css';
import { useTranslation } from "react-i18next";


function Footer() {
const { t } = useTranslation();
    return (
      <footer className="footer">
          <div className="footer_top">
              <div className="container">
                  <div className="row align-items-center">
                      <div className="col-md-6">
                          <div className="footer-logo">
                              <img src="Images/Logo-white.png" />
                          </div>
                      </div>
                      <div className="col-md-6">
                          <ul className="soical-links">
                              <p>{t('follow_us')}</p>
                              <li>
                                  <a href="#" target="_blank"><i className="fa-brands fa-facebook-f"></i></a>

                              </li>
                              <li>
                                  <a href="#" target="_blank"><i className="fa-brands fa-linkedin-in"></i></a>
                              </li>
                              <li>
                                  <a href="#" target="_blank"><i className="fa-brands fa-x-twitter"></i></a>
                              </li>
                              <li>
                                  <a href="#" target="_blank"><i className="fa-brands fa-square-instagram"></i></a>
                              </li>
                              <li>
                                  <a href="#" target="_blank"><i className="fa-brands fa-youtube"></i></a>
                              </li>
                          </ul>
                      </div>
                  </div>
                  <div className="row mt-4 m-mt-0 g-4">

                      <div className="col-sm-4 col-md-4 col-lg-3 col-xl-3">
                          <h6>{t('specialises_in_providing_high_class_tours_for_those_in_need_contact_us')}</h6>
                          <ul className="icon-links">
                              <li>
                                  <a href="#" target="_blank"><i className="fa-solid fa-location-dot"></i>{t('address_moshav_tarom')}</a>
                              </li>
                              <li>
                                  <a href="#" target="_blank"><i className="fa-solid fa-clock"></i>{t('operating_hours_09_00_17_00')}</a>
                              </li>
                              <li>
                                  <a href="#" target="_blank"><i className="fa-solid fa-phone-volume"></i>{t('02_970_9705')}</a>
                              </li>
                              <li>
                                  <a href="#" target="_blank"><i className="fa-solid fa-mobile-retro"></i>{t('02_533_6134')}</a>
                              </li>
                              <li>
                                  <a href="mailto:info@ecobuild.co.il" target="_blank"><i
                                          className="fa-solid fa-envelope"></i>{t('info_ecobuild_co_il')}</a>
                              </li>
                          </ul>
                      </div>
                      <div className="col-sm-4 col-md-4 col-lg-3 col-xl-3">
                          <h5>{t('most_viewed')}</h5>
                          <ul className="footer-nav-links">
                              <li>
                                  <a href="#" target="_blank">{t('nudura_adapter_for_high_walls')}</a>
                              </li>
                              <li>
                                  <a href="#" target="_blank">{t('ceiling_and_floor_technology')}</a>
                              </li>
                              <li>
                                  <a href="#" target="_blank">{t('explosion_resistance_test')}</a>
                              </li>
                              <li>
                                  <a href="#" target="_blank">{t('alignment_systems')}</a>
                              </li>
                              <li>
                                  <a href="#" target="_blank">{t('website_accessibility_statement')}</a>
                              </li>

                          </ul>
                      </div>
                      <div className="col-sm-4 col-md-4 col-lg-3 col-xl-3">
                          <h5>{t('links_on_the_site')}</h5>
                          <ul className="footer-nav-links">

                          <li className="dropdown">
                              <a className="dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                  aria-expanded="false">{t('about')}</a>
                              <ul className="dropdown-menu">
                                  <li>
                                  <Link className="dropdown-item" to="/aboutus">{t('write_about_us')}</Link></li>
                                  <li><a className="dropdown-item" href="#">{t('write_about_us_in_the_press')}</a></li>
                                  <li>
                                  <Link className="dropdown-item" to="/broadcastnews">{t('broadcast_news')}</Link>
                                  </li>
                                  <li>
                                      <Link className="dropdown-item" to="/faq">{t('frequently_asked_questions_about_nudura_ecobuild')}</Link>
                                  </li>

                                
                              </ul>
                          </li>
                              
                              <li>
                                  <a href="#" target="_blank">{t('icf')}</a>
                              </li>
                              <li>
                                  <a href="#" target="_blank">{t('nudura_combined_series')}</a>
                              </li>
                              <li>
                                  <a href="#" target="_blank">{t('retrofit_insulation_technology')}</a>
                              </li>
                              <li>
                                  <a href="#" target="_blank">{t('advanced_construction_methods')}</a>
                              </li>

                          </ul>
                      </div>
                      <div className="col-sm-12 col-md-12 col-lg-3 col-xl-3">
                          <div className="newsletter-band">
                              <h5>{t('newsletter')}</h5>
                              <p>{t('subscribe_to_our_newsletter_now_and_receive_hot_updates_in_the_construction_industry')}</p>
                              <div className="form-group ">
                                  <span className="send-icon"><img src="Images/Icons/send.svg" /></span>
                                  <input type="email" className="form-control" id="inputEmail4"
                                      placeholder={t('your_email_address')}   style={{ color: "white" }} />
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
          <div className="footer_bottom">
              <div className="container">
                  <hr className="line-divider" />
                  <div className="row">
                      <div className="col-md-7">
                          <p className="p-bg-text">{t('2025')}<a href="#" target="_blank" className="text-white">{t('ecobuild_system_ltd')}</a>{t('all_rights_reserved')}</p>
                      </div>
                      <div className="col-md-5">
                          <ul className="footer-nav-links flex-row">
                              <li>
                                  <a href="#" target="_blank">{t('terms_of_use_of_the_website')}</a>
                              </li>
                              <li>
                                  <a href="#" target="_blank">{t('privacy_policy')}</a>
                              </li>
                              <li>
                                  <a href="#" target="_blank">{t('cookie_policy')}</a>
                              </li>

                          </ul>
                      </div>

                  </div>
              </div>
          </div>
      </footer>
  );
}

export default Footer;
